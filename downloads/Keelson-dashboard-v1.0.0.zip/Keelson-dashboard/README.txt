Keelson Dashboard  (version 1.0.0)
====================================

A one-page executive dashboard for any project plan. Macro-free, nothing uploaded anywhere.

WHAT'S INSIDE
  Keelson-Dashboard.xlsx          Blank. Paste your plan and the dashboard builds itself.
  Keelson-Dashboard-SAMPLE.xlsx   Filled with a fictional project (an MS Project export) so you can see it working.
  Keelson-Dashboard-SAMPLE.pdf    What the printed one-pager looks like.

THREE STEPS (about five minutes)
  1. Paste Plan tab: click A1, paste your whole plan including the header row.
  2. Setup tab: check each item has a green tick or a dash. Columns are matched by header name
     (Finish, End Date, Due Date, Resource Names, Assignee, % Complete, Outline Level, WBS, Phase ...).
     If one is wrong, pick the right column from the dropdown next to it. Set the status date.
  3. Dashboard tab: type 2-3 key messages, then File > Print > Save as PDF (one landscape page),
     or copy the area into PowerPoint (Paste > Picture).

WORKS WITH
  MS Project (copy the table, or File > Save As > Excel Workbook), Smartsheet, Asana, Monday, Wrike, Jira,
  Planner (export to Excel/CSV), a client's own Excel tracker (title rows above the headers are fine),
  and Keelson's own Project Plan.
  Text dates such as "Mon 1/12/26", "12/01/2026", "12-Jan-2026", "12/Jan/26 9:00 AM" and "2026-01-12" are read;
  the day/month order is worked out from your data and can be set on Setup.

COMPATIBILITY
  Excel for Microsoft 365 and Excel 2021 or later (Windows, Mac, web); Google Sheets (File > Import).
  Status of this release: every formula is verified automatically in LibreOffice against an independent
  reference calculation, using five differently shaped plans. Please tell us if anything looks different
  in your Excel or Google Sheets.

KNOWN LIMITS (v1)
  1,000 plan rows · 50 columns · header row within the first 10 rows · one task per row
  Working days are Monday-Friday (holidays are not taken into account in variance figures).
  Month names in text dates must be English (Jan-Dec).

SUPPORT
  support@keelson.co.in  ·  https://keelson.co.in

The sample company, people and project are fictional.
